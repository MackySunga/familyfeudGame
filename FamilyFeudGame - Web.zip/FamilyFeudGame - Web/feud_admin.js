(function () {
  const Feud = window.FeudGame;
  let state = Feud.loadState();

  // ==== Sound player using WAV audio files ====
  // These files should be in the same folder:
  //   correct_star.wav, wrong_buzz.wav, audience_clap.wav, countdown.wav

  const correctAudio   = new Audio("correct_star.wav");   // correct answer
  const wrongAudio     = new Audio("wrong_buzz.wav");     // wrong answer
  const clapAudio      = new Audio("audience_clap.wav");  // audience clapping
  const countdownAudio = new Audio("countdown.wav");      // countdown sound

  const heartbeatAudio = new Audio("heartbeat.wav");      // heartbeat sound 
  const allwinnerAudio  = new Audio("all_winner.wav");     // all winner sound  
  const buzzmeAudio    = new Audio("buzz_me.wav");        // buzz me sound

  // Volume (0.0 to 1.0)
  correctAudio.volume   = 0.8;
  wrongAudio.volume     = 0.9;
  clapAudio.volume      = 0.9;
  countdownAudio.volume = 0.8;
  heartbeatAudio.volume = 0.7;
  allwinnerAudio.volume = 0.8;
  buzzmeAudio.volume   = 0.9;

  function sendEventToShow(type) {
    try {
      localStorage.setItem(
        "feud_last_event",
        JSON.stringify({ type, ts: Date.now() })
      );
    } catch (e) {
      console.warn("Failed to signal event to show screen.", e);
    }
  }

  function playCorrectSound() {
    correctAudio.currentTime = 0;
    correctAudio.play();
    sendEventToShow("correct");
  }

  function playWrongSound() {
    wrongAudio.currentTime = 0;
    wrongAudio.play();
    sendEventToShow("wrong");
  }

  function playClapSound() {
    clapAudio.currentTime = 0;
    clapAudio.play();
  }

  function playCountdownSound() {
    countdownAudio.currentTime = 0;
    countdownAudio.play();
  }

  function playHeartbeatSound() {
    heartbeatAudio.currentTime = 0;
    heartbeatAudio.play();
  } 

  function playAllWinnerSound() {
    allwinnerAudio.currentTime = 0;
    allwinnerAudio.play();
  }

  function playBuzzMeSound() {
    buzzmeAudio.currentTime = 0;
    buzzmeAudio.play();
  }

  // Send timer commands to show screen
  function sendTimerCommand(cmd) {
    try {
      localStorage.setItem(
        "feud_timer_cmd",
        JSON.stringify({ ...cmd, ts: Date.now() })
      );
    } catch (e) {
      console.warn("Failed to send timer command.", e);
    }
  }

  // ==== DOM refs ====
  const questionTextEl = document.getElementById("question-text");
  const qIndicatorEl = document.getElementById("q-indicator");
  const boardEl = document.getElementById("answers-board");
  const questionsListEl = document.getElementById("questions-list");
  const questionSelectEl = document.getElementById("question-select");

  const teamCards = [
    null,
    document.getElementById("team1-card"),
    document.getElementById("team2-card"),
    document.getElementById("team3-card"),
    document.getElementById("team4-card")
  ];
  const teamScoresEls = [
    null,
    document.getElementById("team1-score"),
    document.getElementById("team2-score"),
    document.getElementById("team3-score"),
    document.getElementById("team4-score")
  ];
  const teamButtons = document.querySelectorAll(".team-select");

  const strikeIconsEl = document.getElementById("strike-icons");
  const addStrikeBtn = document.getElementById("add-strike");
  const clearStrikeBtn = document.getElementById("clear-strikes");

  const prevQuestionBtn = document.getElementById("prev-question");
  const nextQuestionBtn = document.getElementById("next-question");
  const resetGameBtn = document.getElementById("reset-game");
  const resetQuestionsBtn = document.getElementById("reset-questions");
  const editQuestionBtn = document.getElementById("edit-question");

  // Team names inputs
  const teamNameInputs = [
    null,
    document.getElementById("team-name-1"),
    document.getElementById("team-name-2"),
    document.getElementById("team-name-3"),
    document.getElementById("team-name-4")
  ];
  const teamNamesSaveBtn = document.getElementById("team-names-save");
  const teamNamesResetBtn = document.getElementById("team-names-reset");

  // Sound effect buttons
  const btnClap = document.getElementById("btn-clap");
  const btnCountdown = document.getElementById("btn-countdown");
  const btnHeartbeat = document.getElementById("btn-heartbeat");
  const btnAllWinner = document.getElementById("btn-all-winner");
  const btnBuzzMe = document.getElementById("btn-buzz-me");

  // Timer controls
  const timerSecondsInput = document.getElementById("timer-seconds-input");
  const timerStartBtn = document.getElementById("timer-start");
  const timerPauseBtn = document.getElementById("timer-pause");
  const timerResetBtn = document.getElementById("timer-reset");
  const timerToggleVisibleBtn = document.getElementById("timer-toggle-visible");
  let timerVisible = false;

  // Screen mode buttons
  const modeSplashBtn = document.getElementById("mode-splash");
  const modeBoardBtn = document.getElementById("mode-board");
  const modeFastBtn = document.getElementById("mode-fast");

  // Editor DOM
  const editorPanel = document.getElementById("editor-panel");
  const editQuestionTextInput = document.getElementById("edit-question-text");
  const editorAnswersContainer = document.getElementById("editor-answers");
  const editorCancelBtn = document.getElementById("editor-cancel");
  const editorSaveBtn = document.getElementById("editor-save");
  const editorResetQuestionBtn = document.getElementById("editor-reset-question");

  const MAX_EDITOR_ANSWERS = 7;
  let editorAnswerTextInputs = [];
  let editorAnswerPointsInputs = [];
  let editorOpen = false;

  // ==== Helpers ====
  function ensureRevealedLength() {
    const answersCount =
      Feud.questions[state.currentQuestionIndex].answers.length;
    if (!Array.isArray(state.revealed)) {
      state.revealed = new Array(answersCount).fill(false);
    } else if (state.revealed.length !== answersCount) {
      const old = state.revealed;
      state.revealed = new Array(answersCount).fill(false);
      for (let i = 0; i < answersCount && i < old.length; i++) {
        state.revealed[i] = !!old[i];
      }
    }
  }

  function save() {
    ensureRevealedLength();
    Feud.saveState(state);
  }

  function getTeamName(t) {
    if (
      state.teamNames &&
      typeof state.teamNames[t] === "string" &&
      state.teamNames[t].trim() !== ""
    ) {
      return state.teamNames[t];
    }
    return `Team ${t}`;
  }

  // ==== Renderers ====
  function renderQuestionArea() {
    const q = Feud.questions[state.currentQuestionIndex];
    questionTextEl.textContent = q.text;
    qIndicatorEl.textContent = `Question ${
      state.currentQuestionIndex + 1
    } of ${Feud.questions.length}`;
    if (questionSelectEl) {
      questionSelectEl.value = String(state.currentQuestionIndex);
    }
  }

  function renderBoard() {
    ensureRevealedLength();
    const q = Feud.questions[state.currentQuestionIndex];
    boardEl.innerHTML = "";

    q.answers.forEach((ans, idx) => {
      const card = document.createElement("div");
      card.className = "answer-card";
      if (state.revealed[idx]) {
        card.classList.add("revealed-admin");
      }
      const label = state.revealed[idx]
        ? "REVEALED"
        : "Hidden (click to reveal)";

      card.innerHTML = `
        <div class="answer-content">
          <div class="slot-number">${idx + 1}</div>
          <div class="answer-text">${ans.text}</div>
          <div class="answer-points">${ans.points}</div>
        </div>
        <div class="admin-reveal-label">${label}</div>
      `;

      card.addEventListener("click", () => {
        if (state.revealed[idx]) return;
        state.revealed[idx] = true;
        if (state.activeTeam >= 1 && state.activeTeam <= 4) {
          state.teamScores[state.activeTeam] += ans.points;
        }
        save();
        renderAll();
        playCorrectSound();
      });

      boardEl.appendChild(card);
    });
  }

  function renderScores() {
    for (let t = 1; t <= 4; t++) {
      if (teamScoresEls[t]) {
        teamScoresEls[t].textContent = state.teamScores[t] || 0;
      }
      const card = teamCards[t];
      if (card) {
        const nameEl = card.querySelector(".team-name");
        if (nameEl) nameEl.textContent = getTeamName(t);
      }
    }
  }

  function renderActiveTeam() {
    for (let t = 1; t <= 4; t++) {
      const card = teamCards[t];
      if (card) {
        card.classList.toggle("active", state.activeTeam === t);
      }
    }
    teamButtons.forEach((btn) => {
      const teamNum = Number(btn.dataset.team);
      btn.classList.toggle("active", teamNum === state.activeTeam);
    });
  }

  function renderStrikes() {
    const totalSlots = 3;
    let txt = "";
    for (let i = 0; i < totalSlots; i++) {
      txt += i < state.strikes ? "X" : "·";
      if (i < totalSlots - 1) txt += " ";
    }
    strikeIconsEl.textContent = txt;
  }

  function renderQuestionSelect() {
    if (!questionSelectEl) return;
    questionSelectEl.innerHTML = "";
    Feud.questions.forEach((q, idx) => {
      const opt = document.createElement("option");
      opt.value = String(idx);
      const label =
        q.text.length > 60 ? q.text.slice(0, 60) + "…" : q.text;
      opt.textContent = `${idx + 1}. ${label}`;
      questionSelectEl.appendChild(opt);
    });
    questionSelectEl.value = String(state.currentQuestionIndex);
  }

  function renderQuestionsList() {
    if (!questionsListEl) return;
    questionsListEl.innerHTML = "";
    Feud.questions.forEach((q, qIndex) => {
      const wrapper = document.createElement("div");
      wrapper.className = "question-item";
      const isCurrent = qIndex === state.currentQuestionIndex;
      wrapper.innerHTML = `
        <h3>${qIndex + 1}. ${q.text}${
        isCurrent ? ' <span class="current-tag">(current)</span>' : ""
      }</h3>
        <ul class="question-answers-list">
          ${q.answers
            .map(
              (a) => `<li>${a.text} – <strong>${a.points}</strong></li>`
            )
            .join("")}
        </ul>
      `;
      questionsListEl.appendChild(wrapper);
    });
  }

  function renderTeamNameInputs() {
    for (let t = 1; t <= 4; t++) {
      const inp = teamNameInputs[t];
      if (inp) {
        inp.value = getTeamName(t);
      }
    }
  }

  function updateModeButtonsUI() {
    const mode = state.screenMode || "board";
    [modeSplashBtn, modeBoardBtn, modeFastBtn].forEach((btn) => {
      if (btn) btn.classList.remove("mode-btn-active");
    });
    if (mode === "splash" && modeSplashBtn) {
      modeSplashBtn.classList.add("mode-btn-active");
    } else if (mode === "fast" && modeFastBtn) {
      modeFastBtn.classList.add("mode-btn-active");
    } else if (modeBoardBtn) {
      modeBoardBtn.classList.add("mode-btn-active");
    }
  }

  function renderAll() {
    renderQuestionSelect();
    renderQuestionArea();
    renderBoard();
    renderScores();
    renderActiveTeam();
    renderStrikes();
    renderQuestionsList();
    renderTeamNameInputs();
    updateModeButtonsUI();
  }

  // ==== Editor helpers ====
  function initEditor() {
    if (!editorAnswersContainer) return;
    editorAnswerTextInputs = [];
    editorAnswerPointsInputs = [];
    editorAnswersContainer.innerHTML = "";
    for (let i = 0; i < MAX_EDITOR_ANSWERS; i++) {
      const row = document.createElement("div");
      row.className = "editor-answer-row";
      row.innerHTML = `
        <label>${i + 1}</label>
        <input type="text" class="editor-answer-text" placeholder="Answer ${
          i + 1
        }" />
        <input type="number" class="editor-answer-points" placeholder="Pts" min="0" max="999" />
      `;
      editorAnswersContainer.appendChild(row);
      const textInput = row.querySelector(".editor-answer-text");
      const ptsInput = row.querySelector(".editor-answer-points");
      editorAnswerTextInputs.push(textInput);
      editorAnswerPointsInputs.push(ptsInput);
    }
  }

  function fillEditorFromCurrentQuestion() {
    const q = Feud.questions[state.currentQuestionIndex];
    editQuestionTextInput.value = q.text;
    for (let i = 0; i < MAX_EDITOR_ANSWERS; i++) {
      const ans = q.answers[i];
      editorAnswerTextInputs[i].value = ans ? ans.text : "";
      editorAnswerPointsInputs[i].value = ans ? ans.points : "";
    }
  }

  function openEditor() {
    if (!editorPanel) return;
    editorOpen = true;
    editorPanel.style.display = "block";
    fillEditorFromCurrentQuestion();
  }

  function closeEditor() {
    if (!editorPanel) return;
    editorOpen = false;
    editorPanel.style.display = "none";
  }

  function saveEditorChanges() {
    const oldQ = Feud.questions[state.currentQuestionIndex];
    const newText =
      editQuestionTextInput.value.trim() || oldQ.text;

    const newAnswers = [];
    for (let i = 0; i < MAX_EDITOR_ANSWERS; i++) {
      const text = editorAnswerTextInputs[i].value.trim();
      const ptsRaw = editorAnswerPointsInputs[i].value.trim();
      if (text !== "" && ptsRaw !== "") {
        const pts = parseInt(ptsRaw, 10);
        if (!Number.isNaN(pts)) {
          newAnswers.push({ text, points: pts });
        }
      }
    }

    if (newAnswers.length === 0) {
      alert("Please enter at least one answer with points.");
      return;
    }

    Feud.setQuestion(state.currentQuestionIndex, {
      text: newText,
      answers: newAnswers
    });

    // Reset strikes and revealed for this question
    state.strikes = 0;
    state.revealed = [];
    save();
    renderAll();
    closeEditor();
  }

  // ==== Event listeners ====

  // Team turn buttons
  teamButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const t = Number(btn.dataset.team);
      if (t >= 1 && t <= 4) {
        state.activeTeam = t;
        save();
        renderActiveTeam();
      }
    });
  });

  // Strikes
  addStrikeBtn.addEventListener("click", () => {
    if (state.strikes < 3) {
      state.strikes += 1;
      save();
      renderStrikes();
      playWrongSound();
    }
  });

  clearStrikeBtn.addEventListener("click", () => {
    state.strikes = 0;
    save();
    renderStrikes();
  });

  // Question navigation
  prevQuestionBtn.addEventListener("click", () => {
    state.currentQuestionIndex =
      (state.currentQuestionIndex - 1 + Feud.questions.length) %
      Feud.questions.length;
    state.strikes = 0;
    state.revealed = [];
    save();
    renderAll();
  });

  nextQuestionBtn.addEventListener("click", () => {
    state.currentQuestionIndex =
      (state.currentQuestionIndex + 1) % Feud.questions.length;
    state.strikes = 0;
    state.revealed = [];
    save();
    renderAll();
  });

  questionSelectEl.addEventListener("change", (e) => {
    const idx = parseInt(e.target.value, 10);
    if (!Number.isNaN(idx)) {
      state.currentQuestionIndex = idx;
      state.strikes = 0;
      state.revealed = [];
      save();
      renderAll();
    }
  });

  // Reset game & questions
  resetGameBtn.addEventListener("click", () => {
    if (confirm("Reset scores and game state?")) {
      state = Feud.createInitialState();
      save();
      renderAll();
    }
  });

  resetQuestionsBtn.addEventListener("click", () => {
    if (
      confirm(
        "Reset ALL questions back to the original default set? (Scores stay the same.)"
      )
    ) {
      Feud.resetAllQuestionsToDefault();
      state.currentQuestionIndex = 0;
      state.strikes = 0;
      state.revealed = [];
      save();
      renderAll();
      if (editorOpen) {
        fillEditorFromCurrentQuestion();
      }
    }
  });

  // Question editor
  editQuestionBtn.addEventListener("click", () => {
    if (editorOpen) closeEditor();
    else openEditor();
  });

  editorCancelBtn.addEventListener("click", () => {
    closeEditor();
  });

  editorSaveBtn.addEventListener("click", () => {
    saveEditorChanges();
  });

  editorResetQuestionBtn.addEventListener("click", () => {
    if (
      confirm(
        "Reset ONLY this question to its original default version?"
      )
    ) {
      Feud.resetQuestionToDefault(state.currentQuestionIndex);
      state.strikes = 0;
      state.revealed = [];
      save();
      renderAll();
      if (editorOpen) {
        fillEditorFromCurrentQuestion();
      }
    }
  });

  // Team names save/reset
  teamNamesSaveBtn.addEventListener("click", () => {
    if (!state.teamNames || !Array.isArray(state.teamNames)) {
      state.teamNames = Feud.defaultTeamNames();
    }
    for (let t = 1; t <= 4; t++) {
      const inp = teamNameInputs[t];
      if (!inp) continue;
      const val = inp.value.trim();
      state.teamNames[t] = val !== "" ? val : `Team ${t}`;
    }
    save();
    renderAll();
  });

  teamNamesResetBtn.addEventListener("click", () => {
    if (
      confirm("Reset team names back to Team 1, Team 2, Team 3, Team 4?")
    ) {
      state.teamNames = Feud.defaultTeamNames();
      save();
      renderAll();
    }
  });

  // Sound effect buttons
  if (btnClap) {
    btnClap.addEventListener("click", () => {
      playClapSound();
    });
  }

  if (btnCountdown) {
    btnCountdown.addEventListener("click", () => {
      playCountdownSound();
    });
  }

  if (btnHeartbeat) {
    btnHeartbeat.addEventListener("click", () => {
      playHeartbeatSound();
    });
  }

  if (btnAllWinner) {
    btnAllWinner.addEventListener("click", () => {
      playAllWinnerSound();
    });
  }

  if (btnBuzzMe) {
    btnBuzzMe.addEventListener("click", () => {
      playBuzzMeSound();
    });
  }

  // Timer buttons
  if (timerStartBtn) {
   timerStartBtn.addEventListener("click", () => {
    let secs = parseInt(timerSecondsInput.value, 10);
    if (Number.isNaN(secs) || secs <= 0) secs = 30;

    // Tell show screen to start countdown
    sendTimerCommand({ action: "start", seconds: secs });

    // Auto-play countdown sound on admin
    playCountdownSound();
    });
  }

  if (timerPauseBtn) {
    timerPauseBtn.addEventListener("click", () => {
      sendTimerCommand({ action: "pause" });
    });
  }

  if (timerResetBtn) {
    timerResetBtn.addEventListener("click", () => {
      let secs = parseInt(timerSecondsInput.value, 10);
      if (Number.isNaN(secs) || secs <= 0) secs = 30;
      sendTimerCommand({ action: "reset", seconds: secs });
    });
  }

  if (timerToggleVisibleBtn) {
    timerToggleVisibleBtn.addEventListener("click", () => {
      timerVisible = !timerVisible;
      sendTimerCommand({ action: "visibility", visible: timerVisible });
      timerToggleVisibleBtn.textContent = timerVisible
        ? "Hide Timer"
        : "Show Timer";
    });
  }

  // Screen mode buttons
  if (modeSplashBtn) {
    modeSplashBtn.addEventListener("click", () => {
      state.screenMode = "splash";
      save();
      renderAll();
    });
  }
  if (modeBoardBtn) {
    modeBoardBtn.addEventListener("click", () => {
      state.screenMode = "board";
      save();
      renderAll();
    });
  }
  if (modeFastBtn) {
    modeFastBtn.addEventListener("click", () => {
      state.screenMode = "fast";
      save();
      renderAll();
    });
  }

  // ==== Init ====
  initEditor();
  renderAll();
})();
