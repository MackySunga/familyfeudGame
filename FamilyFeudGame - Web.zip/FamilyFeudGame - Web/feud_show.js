(function () {
  const Feud = window.FeudGame;
  let state = Feud.loadState();

  const questionTextEl = document.getElementById("question-text");
  const qIndicatorEl = document.getElementById("q-indicator");
  const boardEl = document.getElementById("answers-board");

  

  const teamCards = [
    null,
    document.getElementById("team1-card"),
    document.getElementById("team2-card"),
    document.getElementById("team3-card"),
    document.getElementById("team4-card")
  ];
  const teamScoresEls = [
    null,
    document.getElementById("team1-score"),
    document.getElementById("team2-score"),
    document.getElementById("team3-score"),
    document.getElementById("team4-score")
  ];

  const strikeIconsEl = document.getElementById("strike-icons");
  const activeTeamLabelEl = document.getElementById("active-team-label");

const splashEl = document.getElementById("splash-screen");
const fastPanelEl = document.getElementById("fast-money-panel");
const fastQuestionEl = document.getElementById("fast-question-text");
const fastAnswersEl = document.getElementById("fast-answers");
const fastTeamLabelEl = document.getElementById("fast-team-label");
const fastTeamScoreEl = document.getElementById("fast-team-score");

const timerDisplayEl = document.getElementById("timer-display");
const fastTimerDisplayEl = document.getElementById("fast-timer-display");
const eventFlashEl = document.getElementById("event-flash");


  // Time's up sound (uses the same buzzer file)
const timeupAudio = new Audio("wrong_buzz.wav");  // or "wrong_buz.wav" if that's your filename
timeupAudio.volume = 0.9;

function playTimeUpSound() {
  timeupAudio.currentTime = 0;
  timeupAudio.play();
}

  // Timer state (only show screen manages countdown, admin just sends commands)
  let timerTotal = 30;
  let timerRemaining = 0;
  let timerRunning = false;
  let timerVisible = false;
  let timerIntervalId = null;
  let lastTickTs = null;

  function refreshState() {
    Feud.refreshQuestionsFromStorage();
    state = Feud.loadState();
  }

  function ensureRevealedLength() {
    const answersCount =
      Feud.questions[state.currentQuestionIndex].answers.length;
    if (!Array.isArray(state.revealed)) {
      state.revealed = new Array(answersCount).fill(false);
    } else if (state.revealed.length !== answersCount) {
      const old = state.revealed;
      state.revealed = new Array(answersCount).fill(false);
      for (let i = 0; i < answersCount && i < old.length; i++) {
        state.revealed[i] = !!old[i];
      }
    }
  }

  function getTeamName(t) {
    if (
      state.teamNames &&
      typeof state.teamNames[t] === "string" &&
      state.teamNames[t].trim() !== ""
    ) {
      return state.teamNames[t];
    }
    return `Team ${t}`;
  }

  function renderQuestion() {
    const q = Feud.questions[state.currentQuestionIndex];
    questionTextEl.textContent = q.text;
    qIndicatorEl.textContent = `Question ${
      state.currentQuestionIndex + 1
    } of ${Feud.questions.length}`;
  }

  function renderBoard() {
    ensureRevealedLength();
    const q = Feud.questions[state.currentQuestionIndex];
    boardEl.innerHTML = "";

    q.answers.forEach((ans, idx) => {
      const card = document.createElement("div");
      card.className = "answer-card";
      if (state.revealed[idx]) {
        card.classList.add("revealed");
      }
      card.innerHTML = `
        <div class="answer-content">
          <div class="slot-number">${idx + 1}</div>
          <div class="placeholder">Click to reveal</div>
          <div class="answer-text">${ans.text}</div>
          <div class="answer-points">${ans.points}</div>
        </div>
      `;
      boardEl.appendChild(card);
    });
  }

  function renderScoresAndTeams() {
    for (let t = 1; t <= 4; t++) {
      if (teamScoresEls[t]) {
        teamScoresEls[t].textContent = state.teamScores[t] || 0;
      }
      const card = teamCards[t];
      if (card) {
        const nameEl = card.querySelector(".team-name");
        if (nameEl) nameEl.textContent = getTeamName(t);
        card.classList.toggle("active", state.activeTeam === t);
      }
    }
    if (state.activeTeam >= 1 && state.activeTeam <= 4) {
      activeTeamLabelEl.textContent = `Current turn: ${getTeamName(
        state.activeTeam
      )}`;
    } else {
      activeTeamLabelEl.textContent = "";
    }
  }

  function renderStrikes() {
    const totalSlots = 3;
    let txt = "";
    for (let i = 0; i < totalSlots; i++) {
      txt += i < state.strikes ? "X" : "·";
      if (i < totalSlots - 1) txt += " ";
    }
    strikeIconsEl.textContent = txt;
  }

  // === Fast Money overlay ===
  function renderFastMoneyPanel() {
  if (!fastPanelEl || !fastAnswersEl || !fastQuestionEl) return;
  const q = Feud.questions[state.currentQuestionIndex];
  fastQuestionEl.textContent = q.text;

  // --- Who is playing? ---
  let teamName = "";
  let teamIdx = state.activeTeam;
  if (teamIdx >= 1 && teamIdx <= 4) {
    teamName = getTeamName(teamIdx);
  }

  // Compute Fast Money round points (first 5 answers that are revealed)
  let fastRoundPoints = 0;
  const answersForRound = q.answers.slice(0, 5);
  answersForRound.forEach((ans, idx) => {
    if (state.revealed[idx]) {
      fastRoundPoints += ans.points;
    }
  });

  // Current total score for that team, and base (before this round)
  let totalScore = teamIdx >= 1 && teamIdx <= 4 ? state.teamScores[teamIdx] : 0;
  let baseScore = totalScore - fastRoundPoints;

  if (fastTeamLabelEl) {
    fastTeamLabelEl.textContent = teamName
      ? `Playing: ${teamName}`
      : "";
  }

  if (fastTeamScoreEl) {
    if (teamName) {
      fastTeamScoreEl.textContent = `Round: +${fastRoundPoints} pts  |  Total: ${totalScore} pts`;
    } else {
      fastTeamScoreEl.textContent = "";
    }
  }

  // --- Answers display (same as before) ---
  fastAnswersEl.innerHTML = "";
  const answers = q.answers.slice(0, 5);

  answers.forEach((ans, idx) => {
    const card = document.createElement("div");
    card.className = "fast-answer-card";
    if (!state.revealed[idx]) {
      card.classList.add("hidden");
    }
    card.innerHTML = `
      <div class="fast-answer-label">${idx + 1}</div>
      <div class="fast-answer-text">${ans.text}</div>
      <div class="fast-answer-points">${ans.points}</div>
    `;
    fastAnswersEl.appendChild(card);
  });

  // If less than 5 answers, fill remaining with blank slots
  for (let i = answers.length; i < 5; i++) {
    const card = document.createElement("div");
    card.className = "fast-answer-card hidden";
    card.innerHTML = `
      <div class="fast-answer-label">${i + 1}</div>
      <div class="fast-answer-text">—</div>
      <div class="fast-answer-points">0</div>
    `;
    fastAnswersEl.appendChild(card);
  }
}


  function renderModeOverlays() {
    const mode = state.screenMode || "board";
    if (splashEl) {
      splashEl.style.display = mode === "splash" ? "flex" : "none";
    }
    if (fastPanelEl) {
      fastPanelEl.style.display = mode === "fast" ? "flex" : "none";
      if (mode === "fast") {
        renderFastMoneyPanel();
      }
    }
  }

  // === Timer ===
function updateTimerDisplay() {
  if (!timerDisplayEl) return;

  const sec = Math.max(0, Math.ceil(timerRemaining));
  const minutes = Math.floor(sec / 60);
  const seconds = sec % 60;

  let text;
  if (minutes > 0) {
    text = `${minutes}:${seconds.toString().padStart(2, "0")}`;
  } else {
    text = `${seconds}`;
  }

  const urgent = sec <= 5 && timerRunning;
  const mode = state.screenMode || "board";

  // --- Normal board timer (question area) ---
  if (timerVisible && mode !== "fast") {
    timerDisplayEl.style.display = "inline-block";
    timerDisplayEl.textContent = text;
    timerDisplayEl.classList.toggle("urgent", urgent);
  } else {
    timerDisplayEl.style.display = "none";
    timerDisplayEl.classList.remove("urgent");
  }

  // --- Fast Money timer (inside fast header) ---
  if (fastTimerDisplayEl) {
    if (timerVisible && mode === "fast") {
      fastTimerDisplayEl.style.display = "inline-block";
      fastTimerDisplayEl.textContent = text;
      fastTimerDisplayEl.classList.toggle("urgent", urgent);
    } else {
      fastTimerDisplayEl.style.display = "none";
      fastTimerDisplayEl.classList.remove("urgent");
    }
  }
}



  function stopTimerInterval() {
    if (timerIntervalId != null) {
      clearInterval(timerIntervalId);
      timerIntervalId = null;
    }
  }

function tickTimer() {
  if (!timerRunning) return;
  const now = performance.now();
  const dt = (now - lastTickTs) / 1000;
  lastTickTs = now;
  timerRemaining -= dt;

  if (timerRemaining <= 0) {
    // Clamp to zero
    timerRemaining = 0;
    timerRunning = false;
    stopTimerInterval();

    // Auto-hide timer on show screen
    timerVisible = false;
    updateTimerDisplay();

    // Flash TIME'S UP and play buzzer
    showEventFlash("timeup");
    playTimeUpSound();
  } else {
    updateTimerDisplay();
  }
}


  function startTimer(seconds) {
    timerTotal = seconds > 0 ? seconds : timerTotal || 30;
    timerRemaining = timerTotal;
    timerRunning = true;
    lastTickTs = performance.now();
    stopTimerInterval();
    timerIntervalId = setInterval(tickTimer, 100);
    updateTimerDisplay();
  }

  function pauseTimer() {
    timerRunning = false;
    stopTimerInterval();
    updateTimerDisplay();
  }

  function resetTimer(seconds) {
    timerTotal = seconds > 0 ? seconds : timerTotal || 30;
    timerRemaining = timerTotal;
    timerRunning = false;
    stopTimerInterval();
    updateTimerDisplay();
  }

  function setTimerVisible(vis) {
    timerVisible = !!vis;
    updateTimerDisplay();
  }

  function handleTimerCommand(cmd) {
    if (!cmd || typeof cmd !== "object") return;
    const action = cmd.action;
    if (action === "start") {
      const secs = Number.isFinite(cmd.seconds) ? cmd.seconds : timerTotal || 30;
      startTimer(secs);
    } else if (action === "pause") {
      pauseTimer();
    } else if (action === "reset") {
      const secs = Number.isFinite(cmd.seconds) ? cmd.seconds : timerTotal || 30;
      resetTimer(secs);
    } else if (action === "visibility") {
      setTimerVisible(!!cmd.visible);
    }
  }

  // === CORRECT / WRONG flash ===
  let flashTimeoutId = null;

function showEventFlash(type) {
  if (!eventFlashEl) return;
  if (flashTimeoutId != null) {
    clearTimeout(flashTimeoutId);
    flashTimeoutId = null;
  }

  eventFlashEl.className = "event-flash";
  if (type === "correct") {
    eventFlashEl.classList.add("event-flash-correct");
    eventFlashEl.textContent = "CORRECT!";
  } else if (type === "wrong") {
    eventFlashEl.classList.add("event-flash-wrong");
    eventFlashEl.textContent = "WRONG!";
  } else if (type === "timeup") {
    eventFlashEl.classList.add("event-flash-timeup");
    eventFlashEl.textContent = "TIME'S UP!";
  } else {
    return;
  }

  flashTimeoutId = setTimeout(() => {
    eventFlashEl.className = "event-flash";
    eventFlashEl.textContent = "";
  }, 900);
}


  function renderAll() {
    refreshState();
    renderQuestion();
    renderBoard();
    renderScoresAndTeams();
    renderStrikes();
    renderModeOverlays();
    updateTimerDisplay();
  }

  // Listen to localStorage changes from admin tab
  window.addEventListener("storage", function (e) {
    if (e.key === Feud.STORAGE_KEY || e.key === Feud.QUESTIONS_KEY) {
      renderAll();
    } else if (e.key === "feud_last_event" && e.newValue) {
      try {
        const evt = JSON.parse(e.newValue);
        if (evt && evt.type) {
          showEventFlash(evt.type);
        }
      } catch (err) {
        console.warn("Bad feud_last_event payload", err);
      }
    } else if (e.key === "feud_timer_cmd" && e.newValue) {
      try {
        const cmd = JSON.parse(e.newValue);
        handleTimerCommand(cmd);
      } catch (err) {
        console.warn("Bad feud_timer_cmd payload", err);
      }
    }
  });

  // Initial render
  renderAll();
})();
