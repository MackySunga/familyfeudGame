(function (global) {
  const STORAGE_KEY = "feud_pinoy_state_v1";
  const QUESTIONS_KEY = "feud_pinoy_questions_v1";

  // === Default Filipino questions ===
  const defaultQuestions = [
    {
      text: "Magbanggit ng paboritong almusal ng Pinoy.",
      answers: [
        { text: "Tapsilog / iba pang -silog", points: 26 },
        { text: "Longsilog", points: 18 },
        { text: "Tocilog", points: 14 },
        { text: "Sinangag at itlog lang", points: 12 },
        { text: "Pandesal", points: 10 },
        { text: "Champorado / lugaw / arroz caldo", points: 10 },
        { text: "Kape at tinapay", points: 10 }
      ]
    },
    {
      text: "Lugar sa mall na unang pinupuntahan ng maraming Pinoy.",
      answers: [
        { text: "Food court / kainan", points: 24 },
        { text: "Sinehan / cinema", points: 18 },
        { text: "Department store", points: 16 },
        { text: "Grocery / supermarket", points: 14 },
        { text: "CR / rest room", points: 10 },
        { text: "Arcade / Timezone", points: 10 },
        { text: "Gadgets / tech shops", points: 8 }
      ]
    },
    {
      text: "Bagay na laging nauubusan sa bahay.",
      answers: [
        { text: "Bigas", points: 22 },
        { text: "Ulam / canned goods", points: 18 },
        { text: "Kape", points: 16 },
        { text: "Asukal", points: 14 },
        { text: "Sabon / shampoo", points: 12 },
        { text: "LPG / gasul", points: 10 },
        { text: "WiFi load / data", points: 8 }
      ]
    },
    {
      text: "Trabahong gustong-gusto ng maraming bata paglaki nila.",
      answers: [
        { text: "Doctor", points: 22 },
        { text: "Teacher", points: 18 },
        { text: "Engineer", points: 16 },
        { text: "Police", points: 14 },
        { text: "Pilot", points: 12 },
        { text: "Nurse", points: 10 },
        { text: "Artist / vlogger / streamer", points: 8 }
      ]
    },
    {
      text: "Paboritong pagkain sa handaan o birthday party.",
      answers: [
        { text: "Spaghetti", points: 24 },
        { text: "Fried chicken", points: 22 },
        { text: "Lumpia", points: 18 },
        { text: "Pancit", points: 14 },
        { text: "Lechon", points: 12 },
        { text: "Ice cream", points: 6 },
        { text: "Cake", points: 4 }
      ]
    },
    {
      text: "Bagay na dala ng estudyante bukod sa bag.",
      answers: [
        { text: "Ballpen / lapis", points: 24 },
        { text: "Notebook", points: 20 },
        { text: "Cellphone", points: 18 },
        { text: "Water bottle / tumbler", points: 14 },
        { text: "Laptop / tablet", points: 10 },
        { text: "Payong", points: 8 },
        { text: "Baon / packed lunch", points: 6 }
      ]
    },
    {
      text: "Lugar kung saan madalas ma-late ang mga Pinoy.",
      answers: [
        { text: "Trabaho / office", points: 24 },
        { text: "School / klase", points: 22 },
        { text: "Meetings", points: 18 },
        { text: "Simbahan / misa", points: 12 },
        { text: "Family reunion / handaan", points: 10 },
        { text: "Barkada gimmick", points: 8 },
        { text: "Airport / biyahe", points: 6 }
      ]
    },
    {
      text: "Gawain sa loob ng jeep o bus habang bumibiyahe.",
      answers: [
        { text: "Mag cellphone / scroll sa social media", points: 24 },
        { text: "Matulog / umidlip", points: 20 },
        { text: "Makinig sa music", points: 18 },
        { text: "Makipag-usap sa katabi", points: 14 },
        { text: "Kumain / magmeryenda", points: 10 },
        { text: "Manood sa bintana", points: 8 },
        { text: "Magbasa (libro / module)", points: 6 }
      ]
    }
  ];

  function cloneQuestions(srcArray) {
    return srcArray.map((q) => ({
      text: String(q.text || ""),
      answers: Array.isArray(q.answers)
        ? q.answers.map((a) => ({
            text: String(a.text || ""),
            points: Number.isFinite(a.points) ? a.points : 0
          }))
        : []
    }));
  }

  function loadQuestionsFromStorage() {
    try {
      const raw = localStorage.getItem(QUESTIONS_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed) || parsed.length === 0) return null;
      return cloneQuestions(parsed);
    } catch (e) {
      console.warn("Failed to load custom questions, using defaults.", e);
      return null;
    }
  }

  // Current questions (mutable)
  let questions = (function initQuestions() {
    const custom = loadQuestionsFromStorage();
    const src = custom || defaultQuestions;
    return cloneQuestions(src);
  })();

  function saveQuestionsToStorage() {
    try {
      localStorage.setItem(QUESTIONS_KEY, JSON.stringify(questions));
    } catch (e) {
      console.warn("Failed to save questions.", e);
    }
  }

  function refreshQuestionsFromStorage() {
    const custom = loadQuestionsFromStorage();
    const src = custom || defaultQuestions;
    questions = cloneQuestions(src);
    if (global.FeudGame) {
      global.FeudGame.questions = questions;
    }
  }

  function getDefaultTeamNames() {
    return ["", "Team 1", "Team 2", "Team 3", "Team 4"];
  }

  function createInitialState() {
    const answersCount =
      questions.length > 0 ? questions[0].answers.length : 0;
    return {
      currentQuestionIndex: 0,
      teamScores: [0, 0, 0, 0, 0], // indices 1–4 used
      activeTeam: 1,
      strikes: 0,
      revealed: new Array(answersCount).fill(false),
      teamNames: getDefaultTeamNames(),
      screenMode: "splash" // "splash", "board", "fast"
    };
  }

  function normalizeTeamNames(rawTeamNames) {
    const names = getDefaultTeamNames();
    if (Array.isArray(rawTeamNames)) {
      for (let i = 1; i <= 4; i++) {
        const direct = rawTeamNames[i];
        const alt = rawTeamNames[i - 1];
        let val = "";
        if (typeof direct === "string" && direct.trim() !== "") {
          val = direct.trim();
        } else if (typeof alt === "string" && alt.trim() !== "") {
          val = alt.trim();
        }
        if (val) names[i] = val;
      }
    }
    for (let i = 1; i <= 4; i++) {
      if (!names[i] || !names[i].trim()) {
        names[i] = `Team ${i}`;
      }
    }
    return names;
  }

  function normalizeState(raw) {
    if (!raw || typeof raw !== "object") return createInitialState();

    // Question index
    let idx =
      typeof raw.currentQuestionIndex === "number"
        ? raw.currentQuestionIndex
        : 0;
    if (idx < 0) idx = 0;
    if (idx >= questions.length) idx = questions.length - 1;
    if (idx < 0) idx = 0;

    // Scores
    const scores = Array.isArray(raw.teamScores)
      ? raw.teamScores.slice(0, 5)
      : [0, 0, 0, 0, 0];
    while (scores.length < 5) scores.push(0);

    // Active team
    const activeTeam = [1, 2, 3, 4].includes(raw.activeTeam)
      ? raw.activeTeam
      : 1;

    // Strikes
    let strikes =
      typeof raw.strikes === "number" && Number.isFinite(raw.strikes)
        ? raw.strikes
        : 0;
    if (strikes < 0) strikes = 0;
    if (strikes > 3) strikes = 3;

    // Revealed answers
    const answersCount =
      questions[idx] && Array.isArray(questions[idx].answers)
        ? questions[idx].answers.length
        : 0;
    const oldRev = Array.isArray(raw.revealed) ? raw.revealed : [];
    const revealed = new Array(answersCount).fill(false);
    for (let i = 0; i < answersCount && i < oldRev.length; i++) {
      revealed[i] = !!oldRev[i];
    }

    // Team names
    const teamNames = normalizeTeamNames(raw.teamNames);

    // Screen mode
    let screenMode =
      typeof raw.screenMode === "string" ? raw.screenMode : "board";
    if (!["splash", "board", "fast"].includes(screenMode)) {
      screenMode = "board";
    }

    return {
      currentQuestionIndex: idx,
      teamScores: scores,
      activeTeam,
      strikes,
      revealed,
      teamNames,
      screenMode
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return createInitialState();
      const parsed = JSON.parse(raw);
      return normalizeState(parsed);
    } catch (e) {
      console.warn("Failed to load state, using default.", e);
      return createInitialState();
    }
  }

  function saveState(state) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn("Failed to save state.", e);
    }
  }

  function setQuestion(index, newQuestion) {
    if (
      typeof index !== "number" ||
      index < 0 ||
      index >= questions.length ||
      !newQuestion ||
      typeof newQuestion !== "object"
    ) {
      return;
    }
    const cleaned = cloneQuestions([newQuestion])[0];
    questions[index] = cleaned;
    saveQuestionsToStorage();
    if (global.FeudGame) {
      global.FeudGame.questions = questions;
    }
  }

  function resetQuestionToDefault(index) {
    if (
      typeof index !== "number" ||
      index < 0 ||
      index >= questions.length ||
      index >= defaultQuestions.length
    ) {
      return;
    }
    const cleaned = cloneQuestions([defaultQuestions[index]])[0];
    questions[index] = cleaned;
    saveQuestionsToStorage();
    if (global.FeudGame) {
      global.FeudGame.questions = questions;
    }
  }

  function resetAllQuestionsToDefault() {
    questions = cloneQuestions(defaultQuestions);
    try {
      localStorage.removeItem(QUESTIONS_KEY);
    } catch (e) {
      console.warn("Failed to clear custom questions.", e);
    }
    if (global.FeudGame) {
      global.FeudGame.questions = questions;
    }
  }

  global.FeudGame = {
    STORAGE_KEY,
    QUESTIONS_KEY,
    questions,
    createInitialState,
    normalizeState,
    loadState,
    saveState,
    setQuestion,
    resetQuestionToDefault,
    resetAllQuestionsToDefault,
    refreshQuestionsFromStorage,
    defaultTeamNames: getDefaultTeamNames
  };
})(window);
